package com.ezen.spm17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootG17ShoppingMallApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootG17ShoppingMallApplication.class, args);
	}

}
